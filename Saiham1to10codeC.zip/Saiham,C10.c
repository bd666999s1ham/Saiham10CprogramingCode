
#include <stdio.h>

int main() {
    int N, i, prime = 1;

    printf("Enter a number: ");
    scanf("%d", &N);

    if (N <= 1) {
        prime = 0;
    } else {
        for (i = 2; i <= N / i; i++) {
            if (N % i == 0) {
                prime = 0;
                break;
            }
        }
    }

    if (prime == 1) {
        printf("Prime number");
    } else {
        printf("Not a prime number");
    }

    return 0;
}

