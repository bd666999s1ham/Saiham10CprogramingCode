
#include <stdio.h>

int main() {
    int N, i;
    unsigned long long fact = 1;

    printf("Enter N (0 to 20): ");
    scanf("%d", &N);

    if (N < 0 || N > 20) {
        printf("Enter a number from 0 to 20.");
        return 0;
    }

    for (i = 1; i <= N; i++) {
        fact = fact * i;
    }

    printf("Factorial = %llu", fact);

    return 0;
}

